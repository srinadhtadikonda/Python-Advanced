from .bookmanagement import *

# Initiate method to display screen components
show_fields()